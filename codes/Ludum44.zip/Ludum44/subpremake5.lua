-- =============================================================================
-- ROOT_PATH/executables/LUDUM/Ludum44
-- =============================================================================

  WindowedApp()
  DependOnLib("CHAOS")
  DependOnLib("DEATH")
  DeclareResource("resources")    
