#include "Ludum44StateMachine.h"
#include "Ludum44Game.h"

LudumStateMachine::LudumStateMachine(class LudumGame * in_game) : 
	death::GameStateMachine(in_game)
{
}