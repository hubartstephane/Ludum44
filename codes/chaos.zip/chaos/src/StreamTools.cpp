#include <chaos/StreamTools.h>

namespace chaos
{
	namespace StreamTools
	{



	} // namespace StringTools

}; // namespace chaos
