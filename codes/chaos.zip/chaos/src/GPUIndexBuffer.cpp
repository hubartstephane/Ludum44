﻿#include <chaos/GPUIndexBuffer.h>

namespace chaos
{

}; // namespace chaos
