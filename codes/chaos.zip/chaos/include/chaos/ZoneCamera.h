#pragma once

#include <chaos/StandardHeaders.h>

namespace chaos
{

	template<typename T>
	class ZoneCamera
	{


	};

}; // namespace chaos
