#include <death/Death.h>

namespace death
{



}; // namespace death

